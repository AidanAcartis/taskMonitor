# main.py
from command_describer.core.describer import CommandDescriber

def main():
    describer = CommandDescriber()
    describer.run()

if __name__ == "__main__":
    main()
