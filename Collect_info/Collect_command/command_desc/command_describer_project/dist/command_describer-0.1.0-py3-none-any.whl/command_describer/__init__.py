# command_describer/__init__.py
"""
Main package: command_describer
Contains modules for parsing, describing, and structuring shell commands.
"""

from .core import *
